package gulde.uic.com.bugtong;

/**
 * Created by USER on 1/11/2018.
 */

public class Bugtong {
    public String bugtong[];
    public String choices[][];
    public String answer[];

    public final int MAX_SIZE = 50;
    public final int TOTAL_SIZE = 50;
    public static int questionShown = 0;
    public static int SCORE = 30;




    public Bugtong() {
        bugtong = new String [MAX_SIZE];
        choices = new String [MAX_SIZE][4];
        answer = new String [MAX_SIZE];
        bugtong[0] = "Isang balong malalim, punong-puno ng patalim.";
        choices[0][0] = "Bibig";
        choices[0][1] = "Ilong";
        choices[0][2] = "Tainga";
        choices[0][3] = "Mata";
        answer[0] = "A";

        bugtong[1] = "Dalawang batong maitim, malayo ang dinarating.";
        choices[1][0] = "Bibig";
        choices[1][1] = "Ilong";
        choices[1][2] = "Tainga";
        choices[1][3] = "Mata";
        answer[1] = "D";

        bugtong[2] = "Dalawang balon, hindi malingon.";
        choices[2][0] = "Bibig";
        choices[2][1] = "Ilong";
        choices[2][2] = "Tainga";
        choices[2][3] = "Mata";
        answer[2] = "C";

        bugtong[3] = "Naligo ang kapitan, hindi nabasa ang tiyan. ";
        choices[3][0] = "Sasakyan";
        choices[3][1] = "Bangka";
        choices[3][2] = "Bola";
        choices[3][3] = "Gulong";
        answer[3] = "B";

        bugtong[4] = "Limang puno ng niyog, isa’y matayog.";
        choices[4][0] = "Siko";
        choices[4][1] = "Binti";
        choices[4][2] = "Hita";
        choices[4][3] = "Daliri";
        answer[4] = "D";

        bugtong[5] = "Kapirasong lupa Napaligiran ng sapa.";
        choices[5][0] = "Pulo";
        choices[5][1] = "Dagat";
        choices[5][2] = "Balon";
        choices[5][3] = "Kanal";
        answer[5] = "A";

        bugtong[6] = "Baboy ko sa kaignin, Tumataba'y walang pagkain.";
        choices[6][0] = "Kahoy";
        choices[6][1] = "Gubat";
        choices[6][2] = "Putik";
        choices[6][3] = "Punso";
        answer[6] = "D";

        bugtong[7] = "Habang kinakain, Lalo kang gugutumin.";
        choices[7][0] = "Hangin";
        choices[7][1] = "Gamot";
        choices[7][2] = "Purga";
        choices[7][3] = "Tableta";
        answer[7] = "C";

        bugtong[8] = "Matanda ang nuno, hindi lumiligo.";
        choices[8][0] = "Aso";
        choices[8][1] = "Pusa";
        choices[8][2] = "Ibon";
        choices[8][3] = "Butiki";
        answer[8] = "B";

        bugtong[9] = "May pitong buhay Kaya mahirap mamatay.";
        choices[9][0] = "Aso";
        choices[9][1] = "Pusa";
        choices[9][2] = "Ibon";
        choices[9][3] = "Butiki";
        answer[9] = "B";

        bugtong[10] = "Matanda ang nuno, hindi lumiligo.";
        choices[10][0] = "Aso";
        choices[10][1] = "Pusa";
        choices[10][2] = "Ibon";
        choices[10][3] = "Butiki";
        answer[10] = "B";

        bugtong[11] = "Kaaway ni Bantay, May siyam na buhay.";
        choices[11][0] = "Aso";
        choices[11][1] = "Pusa";
        choices[11][2] = "Ibon";
        choices[11][3] = "Butiki";
        answer[11] = "B";

        bugtong[12] = "Itim na tinta ang panulat, Ng milyong kamay na kagulat-kagulat.";
        choices[12][0] = "Posit";
        choices[12][1] = "Pusat";
        choices[12][2] = "Ibon";
        choices[12][3] = "Aso";
        answer[12] = "A";

        bugtong[13] = "Kung si Kupido ay pakikinggan Ito ang pinakamahalagang bahagi ng katawan.";
        choices[13][0] = "Paa";
        choices[13][1] = "Ulo";
        choices[13][2] = "Puso";
        choices[13][3] = "Buhok";
        answer[13] = "C";

        bugtong[14] = "Lupang pinitik-pitik, Naglalawa sa paligid.";
        choices[14][0] = "Pulo";
        choices[14][1] = "Dagat";
        choices[14][2] = "Putik";
        choices[14][3] = "Balon";
        answer[14] = "C";

        bugtong[15] = "Masaya Itong pagdiriwang, May banderitas sa bawat lansangan.";
        choices[15][0] = "Pyesta";
        choices[15][1] = "Kaarawan";
        choices[15][2] = "Pasko";
        choices[15][3] = "New Year";
        answer[15] = "A";



        bugtong[16] = "Ama ng Wikang Filipino Sa Pilipinas ay nagiging pangulo.";
        choices[16][0] = "Roxas";
        choices[16][1] = "Aquino";
        choices[16][2] = "Quezon";
        choices[16][3] = "Aguinaldo";
        answer[16] = "C";

        bugtong[17] = "Ama ng Wikang Filipino Sa Pilipinas ay nagiging pangulo.";
        choices[17][0] = "Roxas";
        choices[17][1] = "Aquino";
        choices[17][2] = "Quezon";
        choices[17][3] = "Aguinaldo";
        answer[17] = "C";

        bugtong[18] = "Tuwing Biyernes tayo ay nandirito, Nananalangin sa mahal na Nazareno.";
        choices[18][0] = "Quiapo";
        choices[18][1] = "Quezon";
        choices[18][2] = "Alabang";
        choices[18][3] = "Marikina";
        answer[18] = "A";

        bugtong[19] = "Waland dila, Walang bibig, Maaro mong madining.";
        choices[19][0] = "Kotse";
        choices[19][1] = "Bus";
        choices[19][2] = "Radyo";
        choices[19][3] = "Pito";
        answer[19] = "C";

        bugtong[20] = "Mapulang mukha ko ay tinikan, Ngunit busilak ang kalooban.";
        choices[20][0] = "Rambotan";
        choices[20][1] = "Pomelo";
        choices[20][2] = "Durian";
        choices[20][3] = "Mangga";
        answer[20] = "A";


        bugtong[21] = "Araw-gabi ay tumatakbo, Ang magkapatid na Re at Lo.";
        choices[21][0] = "Relo";
        choices[21][1] = "Panahon";
        choices[21][2] = "Gulong";
        choices[21][3] = "Buhay";
        answer[21] = "A";


        bugtong[22] = "Susun-susong dahon, Bolang binalumbon.";
        choices[22][0] = "Repolyo";
        choices[22][1] = "Kamatis";
        choices[22][2] = "Sibuyas";
        choices[22][3] = "Kang-kong";
        answer[22] = "A";

        bugtong[23] = "Bumubula ang tabo Hindi naman kumukulo";
        choices[23][0] = "Shampoo";
        choices[23][1] = "Tubig";
        choices[23][2] = "Gripo";
        choices[23][3] = "Sabon";
        answer[23] = "D";

        bugtong[24] = "Di na dapat pakuluan, Upang pabulain lamang.";
        choices[24][0] = "Sabon";
        choices[24][1] = "Shampoo";
        choices[24][2] = "Gripo";
        choices[24][3] = "Tubig";
        answer[24] = "A";

        bugtong[24] = "Kawaling bumubula, Wala namang naggata.";
        choices[24][0] = "Sabon";
        choices[24][1] = "Shampoo";
        choices[24][2] = "Gripo";
        choices[24][3] = "Tubig";
        answer[24] = "A";

        bugtong[24] = "Di na dapat pakuluan, Upang pabulain lamang.";
        choices[24][0] = "Sabon";
        choices[24][1] = "Shampoo";
        choices[24][2] = "Gripo";
        choices[24][3] = "Tubig";
        answer[24] = "A";

        bugtong[25] = "Labanan ito ng pupugan, At matulis na tari ng kamatayan.";
        choices[25][0] = "Sabon";
        choices[25][1] = "Shampoo";
        choices[25][2] = "Gripo";
        choices[25][3] = "Tubig";
        answer[25] = "A";

        bugtong[26] = "May pusong kulay pula, Kakabit ng mga daliring nakahilera.";
        choices[26][0] = "Buko";
        choices[26][1] = "Mangga";
        choices[26][2] = "Lansones";
        choices[26][3] = "Saging";
        answer[26] = "D";

        bugtong[27] = "Mga daliring magkakadikit, Di man makakapit.";
        choices[27][0] = "Buko";
        choices[27][1] = "Mangga";
        choices[27][2] = "Lansones";
        choices[27][3] = "Saging";
        answer[27] = "D";

        bugtong[28] = "Aling may matabang katawan, Magkabilang buhok ay tinatalian.";
        choices[28][0] = "Bag";
        choices[28][1] = "Sako";
        choices[28][2] = "Tali";
        choices[28][3] = "Pouch";
        answer[28] = "B";

        bugtong[29] = "Aling mabuting litratong kuhang-kuha sa mukha mo.";
        choices[29][0] = "Salamin";
        choices[29][1] = "Maskara";
        choices[29][2] = "Helmet";
        choices[29][3] = "Frame";
        answer[29] = "A";

        bugtong[30] = "Kuwadro ko sa dingding, Kamukha ng bawat tumitingin.";
        choices[30][0] = "Salamin";
        choices[30][1] = "Maskara";
        choices[30][2] = "Helmet";
        choices[30][3] = "Frame";
        answer[30] = "A";

        bugtong[31] = "Binibigkas ito sa kapwa, Upang kaisipan ay mapaunawa.";
        choices[31][0] = "Bibig";
        choices[31][1] = "Salita";
        choices[31][2] = "Maskara";
        choices[31][3] = "Salamin";
        answer[31] = "B";


        bugtong[32] = "Munting silit na bumaon, Sa daliri ni Corazon.";
        choices[32][0] = "Bibig";
        choices[32][1] = "Salita";
        choices[32][2] = "Salubsob";
        choices[32][3] = "Salamin";
        answer[32] = "C";

        bugtong[33] = "Nakabaluktot na daliri sa sanga ay mauuri.";
        choices[33][0] = "Saging";
        choices[33][1] = "Mangga";
        choices[33][2] = "Lansones";
        choices[33][3] = "Sampalok";
        answer[33] = "D";

        bugtong[34] = "Sinampal muna bago inalok.";
        choices[34][0] = "Saging";
        choices[34][1] = "Mangga";
        choices[34][2] = "Lansones";
        choices[34][3] = "Sampalok";
        answer[34] = "D";

        bugtong[35] = "Hindi naman hari, hindi naman pari Nagsusuot ng sari-sari.";
        choices[35][0] = "Sampayan";
        choices[35][1] = "Clip";
        choices[35][2] = "Kabinet";
        choices[35][3] = "Labada";
        answer[35] = "A";

        bugtong[36] = "May puno, walang sanga, May dahon, walang bunga.";
        choices[36][0] = "Takuri";
        choices[36][1] = "Sandok";
        choices[36][2] = "Pitsel";
        choices[36][3] = "Baso";
        answer[36] = "B";

        bugtong[37] = "Kung tawagin nila'y santo, Hindi naman milagroso.";
        choices[37][0] = "Saging";
        choices[37][1] = "Mangga";
        choices[37][2] = "Santol";
        choices[37][3] = "Sampalok";
        answer[37] = "C";


        bugtong[38] = "Di dapat na kulangin, Di rin dapat pasobrahin.";
        choices[38][0] = "Sapat";
        choices[38][1] = "Tapat";
        choices[38][2] = "Kulang";
        choices[38][3] = "Wala";
        answer[38] = "A";


        bugtong[39] = "Wala sala ay ginapos, Tinapakan pagkatapos.";
        choices[39][0] = "Sapatos";
        choices[39][1] = "Tsinelas";
        choices[39][2] = "Gapos";
        choices[39][3] = "Tapos";
        answer[39] = "A";

        bugtong[40] = "Dala ka niya, Dala mo siya.";
        choices[40][0] = "Sapatos";
        choices[40][1] = "Tsinelas";
        choices[40][2] = "Gapos";
        choices[40][3] = "Tapos";
        answer[40] = "A";

        bugtong[41] = "Buto't balat lumilipad.";
        choices[41][0] = "Ibon";
        choices[41][1] = "Saranggola";
        choices[41][2] = "Hangin";
        choices[41][3] = "Eroplano";
        answer[41] = "B";

        bugtong[42] = "Mga isdang nagsisiksikan, Sa latang kanilang tirahan.";
        choices[42][0] = "Sardinas";
        choices[42][1] = "Corn Beef";
        choices[42][2] = "Gatas";
        choices[42][3] = "Kape";
        answer[42] = "A";

        bugtong[43] = "Kapag bago ay mahina Matiba kapag naluma.";
        choices[43][0] = "Yelo";
        choices[43][1] = "Tubig";
        choices[44][2] = "Semento";
        choices[44][3] = "Buhangin";
        answer[44] = "C";

        bugtong[45] = "Matulis na instrumento Umasinta at pakawalan mo.";
        choices[45][0] = "Sibat";
        choices[45][1] = "Spada";
        choices[45][2] = "Pana";
        choices[45][3] = "Baril";
        answer[45] = "A";

        bugtong[46] = "Habang aking hinihiwa ako ay pinaluluha.";
        choices[46][0] = "Kamatis";
        choices[46][1] = "Sibuyas";
        choices[46][2] = "Kamote";
        choices[46][3] = "Gabi";
        answer[46] = "B";

        bugtong[47] = "Ikaw na humihiwa-hiwa ay siya pang lumuluha";
        choices[47][0] = "Kamatis";
        choices[47][1] = "Sibuyas";
        choices[47][2] = "Kamote";
        choices[47][3] = "Gabi";
        answer[47] = "B";

        bugtong[48] = "Katawan nito'y humihiwa-hiwa kaya ikaw ay lumuluha.";
        choices[48][0] = "Kamatis";
        choices[48][1] = "Sibuyas";
        choices[48][2] = "Kamote";
        choices[48][3] = "Gabi";
        answer[48] = "B";

        bugtong[49] = "Baboy ko sa parang Namumula sa tapang.";
        choices[49][0] = "Suka";
        choices[49][1] = "Kamatis";
        choices[49][2] = "Sili";
        choices[49][3] = "Ketchup";
        answer[49] = "C";















    }


    public String getBugtong(int index){
        return bugtong[index];
    }

    public String getChoices(int index, int choice){
        return choices[index][choice];
    }

    public String getAnswer(int index){
        return answer[index];
    }

    public int getRandomIndex(){
        return 0 + new java.util.Random().nextInt(MAX_SIZE-1);
    }
}
